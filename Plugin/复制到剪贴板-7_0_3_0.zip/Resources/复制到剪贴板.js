﻿var 复制到剪贴板 = (function (_super) {
    __extends(复制到剪贴板, _super);
    function 复制到剪贴板() {
        return _super !== null && _super.apply(this, arguments) || this;
    }

    复制到剪贴板.prototype.execute = function () {
        // Get settings
        var commandSettings = this.CommandParam;
        var objectiveCell = this.evaluateFormula(commandSettings.ObjectiveCell);
        var isAlert = commandSettings.IsAlert;
        var alertData = this.evaluateFormula(commandSettings.AlertData);

        // Add command logic here
        if (objectiveCell != null) {
            const transfer = document.createElement('input');
            transfer.setAttribute('readonly', 'readonly');
            transfer.setAttribute('value', objectiveCell);
            document.body.appendChild(transfer);
            transfer.focus();
            transfer.setSelectionRange(0, 9999);
            if (document.execCommand('copy')) {
                document.execCommand('copy');
            }
            document.body.removeChild(transfer);
            if (isAlert) {
                alert(alertData);
            }
        }
    };

    return 复制到剪贴板;
}(Forguncy.CommandBase));

// Key format is "Namespace.ClassName, AssemblyName"
Forguncy.CommandFactory.registerCommand("复制到剪贴板.复制到剪贴板, 复制到剪贴板", 复制到剪贴板);