var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var SetCurrentRowCommand;
(function (SetCurrentRowCommand_1) {
    var SetCurrentRowCommand = /** @class */ (function (_super) {
        __extends(SetCurrentRowCommand, _super);
        function SetCurrentRowCommand() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        SetCurrentRowCommand.prototype.execute = function () {
            var commandSettings = this.CommandParam;
            if (commandSettings.CurrentRowInfo) {
                Forguncy.Page.setCurrentRow({
                    QueryCondition: commandSettings.CurrentRowInfo,
                    FormulaCalcContext: this.getFormulaCalcContext()
                });
            }
        };
        return SetCurrentRowCommand;
    }(Forguncy.Plugin.CommandBase));
    SetCurrentRowCommand_1.SetCurrentRowCommand = SetCurrentRowCommand;
})(SetCurrentRowCommand || (SetCurrentRowCommand = {}));
Forguncy.Plugin.CommandFactory.registerCommand("SetCurrentRowCommand.SetCurrentRowCommand, SetCurrentRowCommand", SetCurrentRowCommand.SetCurrentRowCommand);
//# sourceMappingURL=SetCurrentRowCommand.js.map