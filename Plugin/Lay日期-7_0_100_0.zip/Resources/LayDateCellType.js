﻿var LayDateCellType = (function (_super) {
    __extends(LayDateCellType, _super);
    function LayDateCellType() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    //自定义的属性
    LayDateCellType.prototype.OADateValue = null;
    //父类CellTypeBase上的方法
    LayDateCellType.prototype.createContent = function () {
        var self = this;
        var element = this.CellElement;
        var cellTypeMetaData = element.CellType;
        var container = $("<div id='" + this.ID + "' style='height:100%' class='ForguncyTextCellType - _RS_LightLine_Translucent_SmallRoundCorner_Normal1 - MAIN'></div>");
        var innerContainer = $('<input class="fgc-inputbox formatInput" type="text" id=' + this.ID + '_laydate />');
        /*innerContainer.css("width", '100%');
        innerContainer.css("height", '100%');
        innerContainer.css("box-sizing", "border-box");
        innerContainer.css("border", "0px");
        innerContainer.css("outline", "none");*/
        var hAlign = this.getHorizontalAlignment(element.StyleInfo);
        if (hAlign) {
            innerContainer.css("text-align", hAlign);
        }
        container.append(innerContainer);
        this.onDependenceCellValueChanged(function () {
            self.loadItems();
        });
        return container;
    };
    //自定义的方法
    LayDateCellType.prototype.getHorizontalAlignment = function (styleInfo) {
        if (styleInfo) {
            if (styleInfo.HorizontalAlignment === Forguncy.CellHorizontalAlignment.Left) {
                return "left";
            } else if (styleInfo.HorizontalAlignment === Forguncy.CellHorizontalAlignment.Center) {
                return "center";
            } else if (styleInfo.HorizontalAlignment === Forguncy.CellHorizontalAlignment.Right) {
                return "right";
            }
        }
        return null;
    };
    //单元格禁用方法
    LayDateCellType.prototype.disable = function () {
        $("#" + this.ID + "_laydate").prop('disabled', true);
    };
    //单元格启用方法
    LayDateCellType.prototype.enable = function () {
        $("#" + this.ID + "_laydate").prop('disabled', false);
    };

    LayDateCellType.prototype.setFontStyle = function (styleInfo) {
        $("#" + this.ID + "_laydate").css('font-size', styleInfo.FontSize);
        $("#" + this.ID + "_laydate").css('font-family', styleInfo.FontFamily);
        $("#" + this.ID + "_laydate").css('font-style', styleInfo.FontStyle);
        $("#" + this.ID + "_laydate").css('font-weight', styleInfo.FontWeight);
        $("#" + this.ID + "_laydate").css('text-decoration', styleInfo.Strikethrough);
        $("#" + this.ID + "_laydate").css('text-decoration', styleInfo.Underline);
        $("#" + this.ID + "_laydate").css('color', Forguncy.ColorHelper.Convert(styleInfo.Foreground));
    };

    LayDateCellType.prototype.setBackColor = function (value) {
        $("#" + this.ID + "_laydate").css('background-color', Forguncy.ColorHelper.Convert(value));
    };

    LayDateCellType.prototype.getValueFromElement = function () {
        return this.OADateValue;
    };

    LayDateCellType.prototype.setValueToElement = function (element, value) {
        if (value !== null && value !== "") {
            if (!(value instanceof Date)) {
                if (typeof value === "number") {
                    value = Forguncy.ConvertOADateToDate(value);
                } else {
                    try {
                        value = new Date(value);
                    } catch (e) {
                        value = null;
                    }
                }
            }
        }

        var info = this.getDateCellTypeTypeAndFormat();
        var type = info.type;
        var format = info.format;
        if (value === null || value === "") {
            $("#" + this.ID + "_laydate").val("");
        } else {
            if (type === "month") {
                value.setDate(1);
            }
            if (type === "year") {
                value.setMonth(1);
                value.setDate(1);
            }
            if (value !== this.OADateValue) {
                if (value) {
                    this.OADateValue = Forguncy.ConvertDateToOADate(value);
                } else {
                    this.OADateValue = null;
                }
            }
            laydate.render({
                elem: "#" + this.ID + "_laydate",
                type: type,
                format: format,
                value: value
            });
        }
    };

    LayDateCellType.prototype.getDefaultValue = function () {
        var cellTypeMetaData = this.CellElement.CellType;
        var defaultValue = cellTypeMetaData.DefaultValue;
        return {
            Value: defaultValue
        };
    };

    LayDateCellType.prototype.onLoad = function () {
        this.loadItems();
    };

    LayDateCellType.prototype.loadItems = function () {
        var self = this;
        var ins22;
        var min;
        var max;
        var info = this.getDateCellTypeTypeAndFormat();
        var type = info.type;
        var format = info.format;
        if (isNaN(info.min) && !isNaN(Date.parse(info.min)) || info.min === "") {
            min = info.min;
        } else {
            min = parseInt(info.min);
        }
        if (isNaN(info.max) && !isNaN(Date.parse(info.max)) || info.max === "") {
            max = info.max;
        } else {
            max = parseInt(info.max);
        }
        var layDateMode = info.layDateMode;
        var newValue;
        this.refreshDom();
        if (min === "" && max !== "") {
            ins22 = laydate.render({    //laydate.js类库中的参数
                elem: "#" + this.ID + "_laydate",
                max: max,
                type: type,
                format: format,
                ready: function () {
                    if (layDateMode === 0) {
                        if (isNaN(max) && !isNaN(Date.parse(max))) {
                            ins22.hint("日期可选值设定在 <br> " + max + "之前");
                        }
                    } else if (layDateMode === 1) {
                        ins22.hint("时间可选值设定在 <br> " + max + "之前");
                    } else if (layDateMode === 2) {
                        ins22.hint("日期时间可选值设定在 <br> " + max + "之前");
                    }
                },
                done: function (value, date, endDate) {
                    if (type === "month") {
                        var newValue = Forguncy.ConvertDateToOADate(new Date(date.year, date.month - 1, 1, 0, 0, 0));
                    } else if (type === "year") {
                        newValue = Forguncy.ConvertDateToOADate(new Date(date.year, 0, 1, 0, 0, 0));
                    } else {
                        newValue = Forguncy.ConvertDateToOADate(new Date(date.year, date.month - 1, date.date, date.hours, date.minutes, date.seconds));
                    }
                    if (type === "time") {
                        newValue = newValue % 1;
                    } else if (type === "date") {
                        newValue = Math.floor(newValue);
                    }

                    if (isNaN(newValue)) {
                        newValue = null;
                    }
                    self.OADateValue = newValue;
                    self.commitValue();    //提交数据层数据
                }
            });
        } else if (min !== "" && max === "") {
            ins22 = laydate.render({    //laydate.js类库中的参数
                elem: "#" + this.ID + "_laydate",
                min: min,
                type: type,
                format: format,
                ready: function () {
                    if (layDateMode === 0) {
                        if (isNaN(min) && !isNaN(Date.parse(min))) {
                            ins22.hint("日期可选值设定在 <br> " + min + "之后");
                        }
                    } else if (layDateMode === 1) {
                        ins22.hint("时间可选值设定在 <br> " + min + "之后");
                    } else if (layDateMode === 2) {
                        ins22.hint("日期时间可选值设定在 <br> " + min + "之后");
                    }
                },
                done: function (value, date, endDate) {
                    if (type === "month") {
                        var newValue = Forguncy.ConvertDateToOADate(new Date(date.year, date.month - 1, 1, 0, 0, 0));
                    } else if (type === "year") {
                        newValue = Forguncy.ConvertDateToOADate(new Date(date.year, 0, 1, 0, 0, 0));
                    } else {
                        newValue = Forguncy.ConvertDateToOADate(new Date(date.year, date.month - 1, date.date, date.hours, date.minutes, date.seconds));
                    }
                    if (type === "time") {
                        newValue = newValue % 1;
                    } else if (type === "date") {
                        newValue = Math.floor(newValue);
                    }

                    if (isNaN(newValue)) {
                        newValue = null;
                    }
                    self.OADateValue = newValue;
                    self.commitValue();    //提交数据层数据
                }
            });
        } else if (min === "" && max === "") {
            ins22 = laydate.render({    //laydate.js类库中的参数
                elem: "#" + this.ID + "_laydate",
                type: type,
                format: format,
                done: function (value, date, endDate) {
                    if (type === "month") {
                        newValue = Forguncy.ConvertDateToOADate(new Date(date.year, date.month - 1, 1, 0, 0, 0));
                    } else if (type === "year") {
                        newValue = Forguncy.ConvertDateToOADate(new Date(date.year, 0, 1, 0, 0, 0));
                    } else {
                        newValue = Forguncy.ConvertDateToOADate(new Date(date.year, date.month - 1, date.date, date.hours, date.minutes, date.seconds));
                    }
                    if (type === "time") {
                        newValue = newValue % 1;
                    } else if (type === "date") {
                        newValue = Math.floor(newValue);
                    }

                    if (isNaN(newValue)) {
                        newValue = null;
                    }
                    self.OADateValue = newValue;
                    self.commitValue();    //提交数据层数据
                }
            });
        } else if (min !== "" && max !== "") {
            ins22 = laydate.render({    //laydate.js类库中的参数
                elem: "#" + this.ID + "_laydate",
                min: min,
                max: max,
                type: type,
                format: format,
                ready: function () {
                    if (layDateMode === 0) {
                        if (isNaN(min) && !isNaN(Date.parse(min))) {
                            ins22.hint("日期可选值设定在 <br> " + min + " 到 " + max);
                        }
                    } else if (layDateMode === 1) {
                        ins22.hint("时间可选值设定在 <br> " + min + " 到 " + max);
                    } else if (layDateMode === 2) {
                        ins22.hint("日期时间可选值设定在 <br> " + min + " 到 " + max);
                    }
                },
                done: function (value, date, endDate) {
                    if (type === "month") {
                        newValue = Forguncy.ConvertDateToOADate(new Date(date.year, date.month - 1, 1, 0, 0, 0));
                    } else if (type === "year") {
                        newValue = Forguncy.ConvertDateToOADate(new Date(date.year, 0, 1, 0, 0, 0));
                    } else {
                        newValue = Forguncy.ConvertDateToOADate(new Date(date.year, date.month - 1, date.date, date.hours, date.minutes, date.seconds));
                    }
                    if (type === "time") {
                        newValue = newValue % 1;
                    } else if (type === "date") {
                        newValue = Math.floor(newValue);
                    }

                    if (isNaN(newValue)) {
                        newValue = null;
                    }
                    self.OADateValue = newValue;
                    self.commitValue();    //提交数据层数据
                }
            });
        }
    };

    LayDateCellType.prototype.getDateCellTypeTypeAndFormat = function () {
        var cellTypeMetaData = this.CellElement.CellType;
        var type = "date";
        var format = "yyyy-MM-dd";
        var min = "";
        var max = "";
        var autoLimit = cellTypeMetaData.AutoLimit;
        var layDateMode = cellTypeMetaData.LayDateMode;
        var beginDateDay = this.evaluateFormula(cellTypeMetaData.BeginDateDay);
        var endDateDay = this.evaluateFormula(cellTypeMetaData.EndDateDay);
        var beginTime = this.evaluateFormula(cellTypeMetaData.BeginTime);
        var endTime = this.evaluateFormula(cellTypeMetaData.EndTime);
        var beginDateTime = this.evaluateFormula(cellTypeMetaData.BeginDateTime);
        var endDateTime = this.evaluateFormula(cellTypeMetaData.EndDateTime);
        if (cellTypeMetaData.LayDateMode === LayDateMode.Time) {
            type = "time";
            format = "HH:mm:ss";
        } else if (cellTypeMetaData.LayDateMode === LayDateMode.DateTime) {
            type = "datetime";
            format = "yyyy-MM-dd HH:mm:ss";
        } else if (cellTypeMetaData.LayDateMode === LayDateMode.Year) {
            type = "year";
            format = "yyyy";
        } else if (cellTypeMetaData.LayDateMode === LayDateMode.Month) {
            type = "month";
            format = "yyyy-MM";
        }
        if (autoLimit) {
            if (cellTypeMetaData.LayDateMode === LayDateMode.Date) {
                if (cellTypeMetaData.LimitedOptional === LimitedOptional.LimitedDate) {
                    if (typeof beginDateDay !== "undefined" && beginDateDay !== null) {
                        min = beginDateDay;
                        min = min.replace(/\//g, "-");
                    }
                    if (typeof endDateDay !== "undefined" && endDateDay !== null) {
                        max = endDateDay;
                        max = max.replace(/\//g, "-");
                    }
                } else {
                    if (typeof beginDateDay !== "undefined" && beginDateDay !== null) {
                        min = beginDateDay;
                        min = parseInt(beginDateDay);
                    }
                    if (typeof endDateDay !== "undefined" && endDateDay !== null) {
                        max = endDateDay;
                        max = parseInt(endDateDay);
                    }
                }
            } else if (cellTypeMetaData.LayDateMode === LayDateMode.Time) {
                if (typeof beginTime !== "undefined" && beginTime !== null) {
                    min = beginTime;
                }
                if (typeof endTime !== "undefined" && endTime !== null) {
                    max = endTime;
                }
            } else if (cellTypeMetaData.LayDateMode === LayDateMode.DateTime) {
                if (typeof beginDateTime !== "undefined" && beginDateTime !== null) {
                    min = beginDateTime;
                    min = min.replace(/\//g, "-");
                }
                if (typeof endDateTime !== "undefined" && endDateTime !== null) {
                    max = endDateTime;
                    max = max.replace(/\//g, "-");
                }
            }
        }
        return {
            type: type,
            format: format,
            min: min,
            max: max,
            layDateMode: layDateMode
        };
    };

    LayDateCellType.prototype.refreshDom = function () {
        var self = this;
        $("#" + self.ID + "_laydate").remove();
        $("#" + self.ID).html('<input class="fgc-inputbox formatInput" type="text" id=' + self.ID + '_laydate />');
    };

    return LayDateCellType;
}(Forguncy.CellTypeBase));

//与c#端数据保持一致
var LayDateMode = {
    Date: 0,
    Time: 1,
    DateTime: 2,
    Year: 3,
    Month: 4
};
var LimitedOptional = {
    LimitedDate: 0,
    LimitedDateoptional: 1
};

// Key format is "Namespace.ClassName, AssemblyName"
Forguncy.CellTypeHelper.registerCellType("LayDateCellType.LayDateCellType, LayDateCellType", LayDateCellType);