var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var TabManager;
(function (TabManager) {
    var TabCellTypeStyleTemplateHelper = /** @class */ (function (_super) {
        __extends(TabCellTypeStyleTemplateHelper, _super);
        function TabCellTypeStyleTemplateHelper() {
            var _this = _super.call(this) || this;
            _this.CellTypeString = "TabManager.TabManager";
            _this.TemplateNameParts = ["TabItem"];
            return _this;
        }
        TabCellTypeStyleTemplateHelper.prototype.MapPartsNameToDom = function (container) {
            return {
                TABITEM: container.find(".".concat("FTM-nav-wrap-list-item" /* TabHeadClassNames.NavListItem */))
            };
        };
        TabCellTypeStyleTemplateHelper.prototype.OnTemplateStyleApplied = function (styleTemplate, container) {
            if (container) {
                // remove overflow hidden
                container.css("overflow", "visible");
                if (styleTemplate &&
                    styleTemplate.Styles &&
                    styleTemplate.Styles["TabItem"] &&
                    styleTemplate.Styles["TabItem"].SelectedStyle) {
                    var activeStyle = styleTemplate.Styles["TabItem"].SelectedStyle;
                    if (activeStyle.Background) {
                        var backgroundColor = Forguncy.ConvertToCssColor(activeStyle.Background);
                        container.find(".".concat("FTM-nav" /* TabHeadClassNames.Nav */)).css('border-bottom-color', backgroundColor);
                    }
                }
            }
        };
        return TabCellTypeStyleTemplateHelper;
    }(TabManager.CellTypeStyleTemplateHelperBase));
    TabManager.TabCellTypeStyleTemplateHelper = TabCellTypeStyleTemplateHelper;
    var TabCellType = /** @class */ (function (_super) {
        __extends(TabCellType, _super);
        function TabCellType() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        TabCellType.prototype.getStyleTemplateHelper = function () {
            return TabCellType.StyleTemplateHelper;
        };
        // override
        TabCellType.prototype.createContent = function () {
            var cellType = this.CellElement.CellType;
            var tabStyle = this.CellElement.StyleTemplate;
            var container = $("<div style=\"width:100%;height:100%;\" />");
            this.tabManager = new TabManager.TabContainer(cellType, tabStyle, this._pageID);
            container.append(this.tabManager.createUI().container);
            return container;
        };
        // override
        TabCellType.prototype.onWindowResized = function () {
            this.tabManager.dispatch("WindowResized" /* TabManagerEvents.WindowResized */);
        };
        // override
        TabCellType.prototype.destroy = function () {
            TabManager.TabContainer.clearTabContainerInstanceCache(this._pageID);
            _super.prototype.destroy.call(this);
        };
        TabCellType.StyleTemplateHelper = new TabCellTypeStyleTemplateHelper();
        return TabCellType;
    }(Forguncy.Plugin.CellTypeBase));
    TabManager.TabCellType = TabCellType;
    var TabOpenCommand = /** @class */ (function (_super) {
        __extends(TabOpenCommand, _super);
        function TabOpenCommand() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        TabOpenCommand.prototype.execute = function () {
            var _this = this;
            // Get setings
            var commandSettings = this.CommandParam;
            var urlTitle = this.evaluateFormula(commandSettings.UrlTitle);
            var pageName = this.evaluateFormula(commandSettings.PageName);
            var url = this.evaluateFormula(commandSettings.Url);
            var isSelectPage = commandSettings.IsSelectPage;
            var passedValueList = commandSettings.PassedValueList || [];
            var usedMode = commandSettings.UsedMode;
            var data = passedValueList.filter(function (item) {
                return item && item.Target;
            }).reduce(function (pre, cur) {
                var source = _this.evaluateFormula(cur.Source);
                var target = _this.evaluateFormula(cur.Target);
                pre[target] = source;
                return pre;
            }, {});
            // Add command logic here
            var tab = new TabManager.Tab(isSelectPage, pageName, url, urlTitle, usedMode, data);
            TabManager.TabContainer.addTab(tab, Forguncy.ForguncyData.pageInfo.pageID);
        };
        return TabOpenCommand;
    }(Forguncy.Plugin.CommandBase));
    TabManager.TabOpenCommand = TabOpenCommand;
    var ResourceHelper = /** @class */ (function () {
        function ResourceHelper() {
        }
        ResourceHelper.getResourceString = function (key) {
            return ResourceHelper.resourceMap[key];
        };
        ResourceHelper.resourceMap = Forguncy.Plugin.LocalizationResourceHelper.getPluginResource("f4d61031-b4c0-435b-af6e-991d81290afd");
        return ResourceHelper;
    }());
    TabManager.ResourceHelper = ResourceHelper;
})(TabManager || (TabManager = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("TabManager.TabCellType, TabManager", TabManager.TabCellType);
Forguncy.Plugin.CommandFactory.registerCommand("TabManager.TabOpenCommand, TabManager", TabManager.TabOpenCommand);
