var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
var TabManager;
(function (TabManager) {
    var EventDispatcher = /** @class */ (function () {
        function EventDispatcher() {
            this._events = new TabManager.Events();
        }
        EventDispatcher.prototype.on = function (eventName, handler) {
            this._events.addHandler(eventName, handler);
        };
        EventDispatcher.prototype.off = function (eventName, handler) {
            this._events.removeHandler(eventName, handler);
        };
        EventDispatcher.prototype.dispatch = function (eventName) {
            var _a;
            var args = [];
            for (var _i = 1; _i < arguments.length; _i++) {
                args[_i - 1] = arguments[_i];
            }
            (_a = this._events).raiseEvent.apply(_a, __spreadArray([eventName], args, false));
        };
        EventDispatcher.prototype.dispose = function () {
            this._events.release();
        };
        return EventDispatcher;
    }());
    TabManager.EventDispatcher = EventDispatcher;
})(TabManager || (TabManager = {}));
