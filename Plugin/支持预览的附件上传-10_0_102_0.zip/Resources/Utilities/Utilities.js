var FilePreviewer;
(function (FilePreviewer) {
    // 修复移动端 Safari 下双击无法预览
    {
        jQuery.event.special.dblclick = {
            setup: function (data, namespaces) {
                var agent = navigator.userAgent.toLowerCase();
                if (agent.indexOf('iphone') >= 0 || agent.indexOf('ipad') >= 0 || agent.indexOf('ipod') >= 0) {
                    var elem = this, $elem = jQuery(elem);
                    $elem.bind('touchend.dblclick', jQuery.event.special.dblclick.handler);
                }
                else {
                    var elem = this, $elem = jQuery(elem);
                    $elem.bind('click.dblclick', jQuery.event.special.dblclick.handler);
                }
            },
            teardown: function (namespaces) {
                var agent = navigator.userAgent.toLowerCase();
                if (agent.indexOf('iphone') >= 0 || agent.indexOf('ipad') >= 0 || agent.indexOf('ipod') >= 0) {
                    var elem = this, $elem = jQuery(elem);
                    $elem.unbind('touchend.dblclick');
                }
                else {
                    var elem = this, $elem = jQuery(elem);
                    $elem.unbind('click.dblclick', jQuery.event.special.dblclick.handler);
                }
            },
            handler: function (event) {
                var elem = event.target, $elem = jQuery(elem), lastTouch = $elem.data('lastTouch') || 0, now = new Date().getTime();
                var delta = now - lastTouch;
                if (delta > 20 && delta < 500) {
                    $elem.data('lastTouch', 0);
                    $elem.trigger('dblclick');
                }
                else {
                    $elem.data('lastTouch', now);
                }
            }
        };
    }
    var OpenFileDialog = /** @class */ (function () {
        function OpenFileDialog() {
        }
        OpenFileDialog.open = function (multiple, accept, onChangeHandler) {
            // Avoid duplicate input elements
            $("#".concat(this.id)).remove();
            var input = $("<input type=\"file\" id=".concat(this.id, " style=\"display:none\" ").concat(multiple ? "multiple" : "", "/>"));
            if (this.isAndroid() && this.isWeChatOrQQBrowser()) {
                accept = null;
            }
            input.attr('accept', accept);
            $(document.body).append(input);
            input.change(function () {
                var fileElement = input[0];
                var results = [];
                for (var i = 0; i < fileElement.files.length; i++) {
                    var file = fileElement.files[i];
                    results.push(file);
                }
                onChangeHandler && onChangeHandler(results);
                input.remove();
            });
            input.click();
        };
        OpenFileDialog.isAndroid = function () {
            var userAgent = navigator.userAgent.toLowerCase();
            return userAgent.indexOf("android") > -1 || userAgent.indexOf("adr") > -1;
        };
        OpenFileDialog.isWeChatOrQQBrowser = function () {
            var userAgent = navigator.userAgent.toLowerCase();
            return userAgent.indexOf("micromessenger") > -1 || userAgent.indexOf("qqbrowser") > -1;
        };
        OpenFileDialog.id = "FP-fileuploader-collapse";
        return OpenFileDialog;
    }());
    FilePreviewer.OpenFileDialog = OpenFileDialog;
    var StringHelper = /** @class */ (function () {
        function StringHelper() {
        }
        StringHelper.isNullOrEmpty = function (value) {
            return value === undefined || value === null || value === "";
        };
        StringHelper.endsWith = function (value, search) {
            return value.indexOf(search, value.length - search.length) !== -1;
        };
        StringHelper.format = function (s) {
            var args = [];
            for (var _i = 1; _i < arguments.length; _i++) {
                args[_i - 1] = arguments[_i];
            }
            if (args.length === 0) {
                return s;
            }
            else if (args.length === 1 && typeof args[0] === "object") {
                var reg = /{([^{}]+)}/gm;
                return s.replace(reg, function (match, name) {
                    return args[0][name];
                });
            }
            else {
                var reg = /{(\d+)}/gm;
                return s.replace(reg, function (match, name) {
                    return args[~~name];
                });
            }
        };
        return StringHelper;
    }());
    FilePreviewer.StringHelper = StringHelper;
    var PlatformInfo = /** @class */ (function () {
        function PlatformInfo() {
        }
        PlatformInfo.isMobile = function () {
            if (/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|Android|Silk|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i.test(navigator.userAgent)
                || /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(navigator.userAgent.substr(0, 4))) {
                return true;
            }
            return false;
        };
        PlatformInfo.isWeChat = function () {
            var ua = window.navigator.userAgent.toLowerCase();
            return ua.indexOf('micromessenger') !== -1;
        };
        return PlatformInfo;
    }());
    FilePreviewer.PlatformInfo = PlatformInfo;
    var GUID = /** @class */ (function () {
        function GUID() {
        }
        GUID.generate = function () {
            return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
                var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
                return v.toString(16);
            });
        };
        return GUID;
    }());
    FilePreviewer.GUID = GUID;
    var UploadLimitChecker = /** @class */ (function () {
        function UploadLimitChecker() {
        }
        UploadLimitChecker.check = function (file, uploadLimit, failCallback) {
            if (uploadLimit) {
                if (uploadLimit.ExtensionFilter) {
                    var fileName_1 = file.name.trim().toLowerCase();
                    var extensions = uploadLimit.ExtensionFilter.split(",").map(function (v) { return v.trim().toLowerCase(); });
                    var match = extensions.some(function (v) { return StringHelper.endsWith(fileName_1, v); });
                    if (!match) {
                        failCallback && failCallback({ raw: file, errorMessage: StringHelper.format(FilePreviewer.Resources.Error_IncorrectFileType, file.name) });
                        return false;
                    }
                }
                if (uploadLimit.SizeLimit) {
                    if (uploadLimit.SizeLimit * 1024 * 1024 < file.size) {
                        failCallback && failCallback({ raw: file, errorMessage: StringHelper.format(FilePreviewer.Resources.Error_IncorrectFileSize, file.name, uploadLimit.SizeLimit) });
                        return false;
                    }
                }
            }
            return true;
        };
        UploadLimitChecker.checkFileCount = function (count, uploadLimit, successCallback, failCallback) {
            if (uploadLimit && uploadLimit.MaxUploadFileCount > 0) {
                if (count > uploadLimit.MaxUploadFileCount) {
                    failCallback && failCallback(StringHelper.format(FilePreviewer.Resources.Error_IncorrectFileCount, uploadLimit.MaxUploadFileCount));
                    return false;
                }
            }
            successCallback && successCallback();
            return true;
        };
        UploadLimitChecker.compressFile = function (file, uploadLimit, callback) {
            if ((uploadLimit === null || uploadLimit === void 0 ? void 0 : uploadLimit.IsCompressImage) && this.allowCompressedFiles.test(file.name)) {
                EXIF.getData(file, function () {
                    EXIF.getAllTags(this);
                    var orientation = EXIF.getTag(this, "Orientation");
                    var reader = new FileReader();
                    reader.onload = function () {
                        var imagePram = { src: this.result, file: file, maxWidth: uploadLimit.MaxWidth, maxHeight: uploadLimit.MaxHeight, orientation: orientation };
                        Forguncy.ImageCompressHelper.getCompressedImageFormData(imagePram, function (formData) {
                            callback(formData.get("file"));
                        });
                    };
                    reader.readAsDataURL(file);
                });
            }
            else {
                callback(file);
            }
        };
        UploadLimitChecker.allowCompressedFiles = /\.(jpe?g|tiff?|png|webp|bmp)$/i;
        return UploadLimitChecker;
    }());
    FilePreviewer.UploadLimitChecker = UploadLimitChecker;
    var UrlHelper = /** @class */ (function () {
        function UrlHelper() {
        }
        UrlHelper.getUrlWithTimestamp = function (url) {
            if (url.indexOf('?') > -1) {
                return url + "&t=" + new Date().getTime();
            }
            else {
                return url + "?t=" + new Date().getTime();
            }
        };
        return UrlHelper;
    }());
    FilePreviewer.UrlHelper = UrlHelper;
})(FilePreviewer || (FilePreviewer = {}));
