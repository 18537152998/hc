var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var FilePreviewer;
(function (FilePreviewer) {
    /**
     * 用户控件
     */
    var UserControl = /** @class */ (function (_super) {
        __extends(UserControl, _super);
        function UserControl() {
            var _this = _super.call(this) || this;
            _this.enabled = true;
            _this.visibility = true;
            _this.focusable = false;
            _this.isFocus = false;
            _this.properties = [];
            _this.registDefaultProperties();
            return _this;
        }
        UserControl.prototype.registDefaultProperties = function () {
            this.registProperty("id");
            this.registProperty("enabled");
            this.registProperty("visibility");
            this.registProperty("focusable");
            this.registProperty("isFocus");
        };
        UserControl.prototype.refresh = function () {
            this.dispatch("Refresh" /* UserControlEvents.Refresh */);
            return this;
        };
        UserControl.prototype.identify = function (id) {
            this.id = id;
            return this;
        };
        UserControl.prototype.show = function () {
            this.refresh();
            this.visibility = true;
            return this;
        };
        UserControl.prototype.hide = function () {
            this.visibility = false;
            return this;
        };
        UserControl.prototype.focus = function () {
            this.isFocus = true;
            return this;
        };
        UserControl.prototype.blur = function () {
            this.isFocus = false;
            return this;
        };
        UserControl.prototype.enable = function () {
            this.enabled = true;
            return this;
        };
        UserControl.prototype.disable = function () {
            this.enabled = false;
            return this;
        };
        UserControl.prototype.dispose = function () {
            this.dispatch("Dispose" /* UserControlEvents.Dispose */);
            _super.prototype.dispose.call(this);
        };
        UserControl.prototype.createUI = function (uiConstructor) {
            if (uiConstructor === void 0) { uiConstructor = this.defaultUI; }
            return new uiConstructor(this);
        };
        UserControl.prototype.bindProperty = function (targetElement, targetName, sourceName) {
            var _this = this;
            // Regist source name
            if (this.properties.indexOf(sourceName) < 0) {
                this.registProperty(sourceName);
            }
            // Regist target name
            if (targetElement.properties.indexOf(targetName) < 0) {
                targetElement.registProperty(targetName);
            }
            // Sync value immediately
            targetElement[targetName] = this[sourceName];
            // Bind target value
            targetElement.on("PropertyChanged" /* UserControlEvents.PropertyChanged */, function (propertyName) {
                if (propertyName === targetName && targetElement) {
                    _this[sourceName] = targetElement[targetName];
                }
            });
            // Bind source value
            this.on("PropertyChanged" /* UserControlEvents.PropertyChanged */, function (propertyName) {
                if (propertyName === sourceName && targetElement) {
                    targetElement[targetName] = _this[sourceName];
                }
            });
        };
        UserControl.prototype.registProperty = function (propertyName, value) {
            var _a;
            if (value === void 0) { value = this[propertyName]; }
            var thisArg = this;
            var privateName = "_" + propertyName.toString();
            this[privateName] = value;
            Object.defineProperties(this, (_a = {},
                _a[propertyName] = {
                    get: function () {
                        return thisArg[privateName];
                    },
                    set: function (value) {
                        if (value !== thisArg[privateName]) {
                            thisArg[privateName] = value;
                            thisArg.onPropertyChanged(propertyName);
                        }
                    }
                },
                _a));
            this.properties.push(propertyName);
        };
        UserControl.prototype.onPropertyChanged = function (propertyName) {
            this.dispatch("PropertyChanged" /* UserControlEvents.PropertyChanged */, propertyName);
        };
        return UserControl;
    }(FilePreviewer.EventDispatcher));
    FilePreviewer.UserControl = UserControl;
    /**
     * 视图基类
     */
    var JQueryUIBase = /** @class */ (function () {
        function JQueryUIBase(target) {
            this.childrenUI = [];
            this.target = target;
            this.createContainer();
            this.createContainerEvents();
            this.refresh();
        }
        JQueryUIBase.prototype.refresh = function () {
            this.disposeChildren();
            this.container.empty();
            this.createChildren();
            return this;
        };
        JQueryUIBase.prototype.dispose = function () {
            this.disposeChildren();
            this.container.remove();
            this.target = undefined;
        };
        JQueryUIBase.prototype.createContainer = function () {
            this.container = $("<div></div>");
        };
        JQueryUIBase.prototype.createContainerEvents = function () {
        };
        JQueryUIBase.prototype.createChildren = function () {
        };
        JQueryUIBase.prototype.disposeChildren = function () {
            var _a;
            (_a = this.childrenUI) === null || _a === void 0 ? void 0 : _a.forEach(function (child) {
                child === null || child === void 0 ? void 0 : child.dispose();
            });
            this.childrenUI = [];
        };
        JQueryUIBase.prototype.addChild = function (jqueryUI, targetContainer) {
            if (targetContainer === void 0) { targetContainer = this.container; }
            if (jqueryUI && targetContainer) {
                this.childrenUI.push(jqueryUI);
                targetContainer.append(jqueryUI.container);
            }
        };
        return JQueryUIBase;
    }());
    FilePreviewer.JQueryUIBase = JQueryUIBase;
    /**
     * 用户控件视图基类
     */
    var ControlUIBase = /** @class */ (function (_super) {
        __extends(ControlUIBase, _super);
        function ControlUIBase(target) {
            var _this = _super.call(this, target) || this;
            // 刷新
            _this.__refreshHandler = function () {
                _this.refresh();
            };
            _this.target.on("Refresh" /* UserControlEvents.Refresh */, _this.__refreshHandler);
            // 属性改变
            _this.__propertyChangedHandler = function (propertyName) {
                _this[propertyName] = _this.target[propertyName];
            };
            _this.target.on("PropertyChanged" /* UserControlEvents.PropertyChanged */, _this.__propertyChangedHandler);
            // 释放
            _this.target.on("Dispose" /* UserControlEvents.Dispose */, function () {
                _this.dispose();
            });
            return _this;
        }
        Object.defineProperty(ControlUIBase.prototype, "id", {
            set: function (value) {
                if (value === "" || value === null || value === undefined) {
                    this.container.removeAttr("id");
                }
                else {
                    this.container.attr("id", value);
                }
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(ControlUIBase.prototype, "enabled", {
            set: function (value) {
                if (value) {
                    this.container.removeClass("FP-disable" /* GeneralCssNames.Disable */);
                    this.container.removeAttr("disabled");
                    this.focusable = this.target.focusable;
                }
                else {
                    this.container.addClass("FP-disable" /* GeneralCssNames.Disable */);
                    this.container.attr("disabled", "disabled");
                    this.focusable = false;
                }
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(ControlUIBase.prototype, "visibility", {
            set: function (value) {
                if (value) {
                    this.container.show();
                }
                else {
                    this.container.hide();
                }
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(ControlUIBase.prototype, "focusable", {
            set: function (value) {
                if (value && this.target.enabled) {
                    this.container.attr("tabindex", "0");
                }
                else {
                    this.container.removeAttr("tabindex");
                }
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(ControlUIBase.prototype, "isFocus", {
            set: function (value) {
                if (value && this.target.focusable) {
                    this.container[0].focus();
                }
                else {
                    this.container[0].blur();
                }
            },
            enumerable: false,
            configurable: true
        });
        ControlUIBase.prototype.refresh = function () {
            _super.prototype.refresh.call(this);
            this.initializeProperties();
            return this;
        };
        ControlUIBase.prototype.dispose = function () {
            this.target.off("Refresh" /* UserControlEvents.Refresh */, this.__refreshHandler);
            this.target.off("PropertyChanged" /* UserControlEvents.PropertyChanged */, this.__propertyChangedHandler);
            _super.prototype.dispose.call(this);
        };
        ControlUIBase.prototype.createContainerEvents = function () {
            this.bindFocusAndBlurEvent();
        };
        ControlUIBase.prototype.initializeProperties = function () {
            var _this = this;
            this.target.properties.forEach(function (propertyName) {
                _this[propertyName] = _this.target[propertyName];
            });
        };
        ControlUIBase.prototype.bindFocusAndBlurEvent = function (container) {
            var _this = this;
            if (container === void 0) { container = this.container; }
            container.on("focus", function () {
                _this.target.focus();
            });
            container.on("blur", function () {
                _this.target.blur();
            });
        };
        return ControlUIBase;
    }(JQueryUIBase));
    FilePreviewer.ControlUIBase = ControlUIBase;
})(FilePreviewer || (FilePreviewer = {}));
