﻿var SmartPhoneCommand = (function (_super) {
    __extends(SmartPhoneCommand, _super);
    function SmartPhoneCommand() {
        return _super !== null && _super.apply(this, arguments) || this;
    }

    SmartPhoneCommand.prototype.execute = function () {
        // Get setings
        var param = this.CommandParam;
        var targetCellFormula = param.TargetCell;
        var cellLocation = this.getCellLocation(targetCellFormula);
        var promise = Forguncy.Page.scanCodeInApp(cellLocation);
        promise.then(function (success) {
            if (!success) {
                var alertText = SmartPhoneCommand.getResourceString("scanCodeAlert");
                alert(alertText);
            }
        });
    };

    SmartPhoneCommand.prototype.GetQRCode = function (cellInfo, qrcode) {
        Forguncy.Page.setScanCodeResultFromApp(cellInfo, qrcode);
    };

    SmartPhoneCommand.getResourceString = function (key) {
        return this.prototype.getPluginResource(key);
    };

    return SmartPhoneCommand;
}(Forguncy.CommandBase));

// Key format is "Namespace.ClassName, AssemblyName"
Forguncy.CommandFactory.registerCommand("SmartPhoneCommand.SmartPhoneCommand, SmartPhoneCommand", SmartPhoneCommand);