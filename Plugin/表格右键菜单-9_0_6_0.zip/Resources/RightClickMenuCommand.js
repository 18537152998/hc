/// <reference path="../Declarations/forguncy.d.ts" />
/// <reference path="../Declarations/forguncy.Plugin.d.ts" />

class RightClickMenuCommand extends Forguncy.Plugin.CommandBase {
    execute() {
        const this2 = this;
        const mldx = this.CommandParam;
        const page = Forguncy.Page;
        const parentElement = document.getElementById('pagesContainer');
        const biaoGeDui1 = document.querySelector(`div[fgcname="${mldx.TableName}"]`);
        const biaoGeDuiXiang = Forguncy.Page.getListView(mldx.TableName);
        ceshi();
        function ceshi() {
            let biaoGeName = mldx.TableName
            let caiDan = mldx.MyProperty;
            let hangSuoYing;
            let lieSuoYing;
            if (biaoGeDui1) {
                document.querySelectorAll(`div[fgcname="${biaoGeName}"] canvas`).forEach(canvas => {
                    canvas.addEventListener('contextmenu', function (event) {
                        chuLiZuoBiao(event);
                    }, true);
                });
                function chuLiZuoBiao(e) {
                    e.preventDefault();
                    let windowWidth = $(window).width();
                    let windowHeight = $(window).height();
                    let canvasElement = document.querySelector(`div[fgcname="${mldx.TableName}"] canvas`);
                    let canvasRect = canvasElement.getBoundingClientRect();
                    let pageX = window.scrollX + canvasRect.left - getScrollOffsets().x;
                    let pageY = window.scrollY + canvasRect.top - getScrollOffsets().y;
                    let mouseX = event.clientX - pageX;
                    let mouseY = event.clientY - pageY;
                    let lieTouGao = biaoGeDuiXiang._grid._colHeaderHeight;
                    let hangTouKuan = biaoGeDuiXiang._grid._rowHeaderWidth;
                    let getActiveSheet1 = biaoGeDuiXiang.getControl().getActiveSheet();
                    let biaoGeHangShu = getActiveSheet1.getRowCount();
                    let biaoGeLieShu = getActiveSheet1.getColumnCount();
                    let shuJuHangGaoDu=0;
                    for (let i = 0; i < biaoGeHangShu; i++) {
                        shuJuHangGaoDu += getActiveSheet1.getRowHeight(i)
                    }
                    let shuJuLieKuanDu=0;
                    for (let i = 0; i < biaoGeLieShu; i++) {
                        shuJuLieKuanDu += getActiveSheet1.getColumnWidth(i);
                    }
                    if (mouseX > hangTouKuan && mouseX < shuJuLieKuanDu + hangTouKuan &&mouseY > lieTouGao && mouseY < shuJuHangGaoDu + lieTouGao) {
                        zuoJanDianJi(canvasElement, e);
                        chuangJianCaiDan();
                        let menu = $("#customContextMenu");
                        let menuWidth = menu.width();
                        let menuHeight = menu.height();
                        let x = e.pageX;
                        let y = e.pageY;
                        if (e.pageX + menuWidth > windowWidth) {
                            x = e.pageX - menuWidth;
                        }
                        if (e.pageY + menuHeight > windowHeight) {
                            y = e.pageY - menuHeight;
                        }
                        menu.css({
                            top: y + "px",
                            left: x + "px"
                        }).show();
                        $("#transparentDiv").show();
                        let suoYingDuiXiang = biaoGeDuiXiang.getControl().getActiveSheet();
                        hangSuoYing = suoYingDuiXiang.getActiveRowIndex();
                        lieSuoYing = suoYingDuiXiang.getActiveColumnIndex();
                    }
                }
            }

            function loadImageOrSvgToElement(image, targetSelector) {
                if (image && image.Name && targetSelector) {
                    let src = "";
                    if (image.BuiltIn) {
                        src = Forguncy.Helper.SpecialPath.getBuiltInImageFolderPath() + image.Name;
                    } else {
                        src = Forguncy.Helper.SpecialPath.getImageEditorUploadImageFolderPath() + encodeURIComponent(image.Name);
                    }
                    if (Forguncy.ImageDataHelper.IsSvg(src)) {
                        $.get(src, (data) => {
                            const svg = $(data.documentElement);
                            Forguncy.ImageHelper.preHandleSvg(svg, image.UseCellTypeForeColor ? "currentColor" : image.Color);
                            svg.css({
                                height: "15px",
                                width: "15px"
                            });
                            $(targetSelector).prepend(svg);
                        });
                    } else {
                        const img = $(`<img src="${src}" alt="${image.Name}"/>`);
                        img.css({
                            height: "15px",
                            width: "15px"
                        });
                        $(targetSelector).html(img);
                    }
                }
            }

            function chuangJianCaiDan() {

                if ($('#customContextMenu').length === 0) {
                    let contextMenuHTML = '<div id="customContextMenu" style=""><ul>'
                    caiDan.forEach(function (ziDuiXiang, i) {
                        contextMenuHTML += `<li id="option${i}"><span class="icon"></span><span class="text">${ziDuiXiang.Name}</span></li>`
                    });
                    contextMenuHTML += '</ul>' + '</div>';
                    $('body').append(contextMenuHTML);
                    caiDan.forEach(function (ziDuiXiang, i) {
                        loadImageOrSvgToElement(ziDuiXiang.MyProperty, `#option${i}>.icon`);
                    });
                    let transparentDiv = '<div id="transparentDiv"></div>';
                    $('body').append(transparentDiv);
                    $("#transparentDiv").on("click", function () {
                        $("#customContextMenu").remove();
                        $(this).remove();
                    });
                    $("#transparentDiv").on("contextmenu", function (e) {
                        e.preventDefault();
                        $("#customContextMenu").remove();
                        $(this).remove();
                    });
                    caiDan.forEach(function (ziDuiXiang, i) {
                        $(`#option${i}`).on("click", function () {
                            setTimeout(function () {
                                $("#customContextMenu").remove();
                                $("#transparentDiv").remove();
                            }, 10);
                            setTimeout(function () {
                                const command = ziDuiXiang.MyDianJiMingLing
                                if (command) {
                                    const initPrarm = {};
                                    initPrarm[command.ParamProperties["contextX"]] = hangSuoYing;
                                    initPrarm[command.ParamProperties["contextY"]] = lieSuoYing;
                                    this2.executeCustomCommandObject(command, initPrarm);
                                   }
                            }, 10);
                        });
                        $(`#option${i}`).on("contextmenu", function (e) {
                            e.preventDefault();
                            $("#customContextMenu").remove();
                            $("#transparentDiv").remove();
                        });

                    });
                }
            }
            function getScrollOffsets() {
                let scrollX = window.scrollX || window.pageXOffset;
                let scrollY = window.scrollY || window.pageYOffset;
                return {
                    x: scrollX,
                    y: scrollY
                };
            }
            function zuoJanDianJi(canvasElement, event) {
                let mouseX = event.clientX;
                let mouseY = event.clientY;
                const mouseDownEvent = new MouseEvent('mousedown', {
                    bubbles: true,
                    cancelable: true,
                    view: window,
                    button: 0, 
                    clientX: mouseX,
                    clientY: mouseY,
                });
                const mouseUpEvent = new MouseEvent('mouseup', {
                    bubbles: true,
                    cancelable: true,
                    view: window,
                    button: 0, 
                    clientX: mouseX,
                    clientY: mouseY,
                });
                canvasElement.dispatchEvent(mouseDownEvent);
                canvasElement.dispatchEvent(mouseUpEvent);
            }
        }
    }
}
Forguncy.Plugin.CommandFactory.registerCommand("RightClickMenu.RightClickMenuCommand, RightClickMenu", RightClickMenuCommand);