﻿var 汉字转拼音 = (function (_super) {
    __extends(汉字转拼音, _super);
    function 汉字转拼音() {
        return _super !== null && _super.apply(this, arguments) || this;
    }

    汉字转拼音.prototype.execute = function () {
        // Get settings
        var commandSettings = this.CommandParam;
        var normalProperty = commandSettings.NormalProperty;
        var formulaProperty = commandSettings.FormulaProperty;
        var formulaValue = this.evaluateFormula(formulaProperty);

        // Add command logic here
        alert("execute command: " + normalProperty + " " + formulaValue);
    };

    return 汉字转拼音;
}(Forguncy.CommandBase));

// Key format is "Namespace.ClassName, AssemblyName"
Forguncy.CommandFactory.registerCommand("汉字转拼音.汉字转拼音, 汉字转拼音", 汉字转拼音);